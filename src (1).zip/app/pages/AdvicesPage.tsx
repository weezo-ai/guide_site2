import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, FileText, Clock, CheckCircle, Lightbulb } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface AdviceType {
  id: number;
  title: string;
  category: string;
  timeline: string;
  steps: string[];
  details: string;
  image: string;
}

const advices: AdviceType[] = [
  {
    id: 1,
    title: "Talaba Hujjatlarini Olish",
    category: "Ro'yxatdan o'tish",
    timeline: "1-2 hafta",
    steps: [
      "Onlayn ariza formasini to'ldiring",
      "Kerakli hujjatlarni yuklang (pasport, foto, sertifikatlar)",
      "Universitet bankida ro'yxatga olish to'lovini to'lang",
      "To'lov kvitansiyasi bilan Xorijiy Talabalar Bo'limiga tashrif buyuring",
      "Talaba ID va hujjatlarni oling",
    ],
    details: "Hujjatlarni rasmiylashtirish jarayoni oddiy va tez. Barcha hujjatlar tayyor bo'lganda, 1-2 hafta ichida talaba ID olishingiz mumkin. Savollar bo'lsa, Xorijiy Talabalar Bo'limiga murojaat qiling.",
    image: "https://images.unsplash.com/photo-1771758249853-415175dc29b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N1bWVudHMlMjBwYXBlcndvcmslMjBvZmZpY2V8ZW58MXx8fHwxNzc0Mjk1OTI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    title: "Viza Uzaytirish Jarayoni",
    category: "Immigratsiya",
    timeline: "2-4 hafta",
    steps: [
      "Viza muddatini tekshiring (30 kun oldin ariza bering)",
      "Kerakli hujjatlarni tayyorlang (pasport, ro'yxatdan o'tish xati, moliyaviy isboti)",
      "Xorijiy Talabalar Bo'limida ariza topshiring",
      "Viza uzaytirish to'lovini to'lang",
      "Kerak bo'lsa, immigratsiya suhbatida qatnashing",
      "Uzaytirilgan vizani oling",
    ],
    details: "Viza uzaytirish jarayoni 2-4 hafta davom etadi. Vaqtida ariza berishni unutmang. Barcha hujjatlar to'g'ri tayyorlangan bo'lsa, muammo bo'lmaydi.",
    image: "https://images.unsplash.com/photo-1771758249853-415175dc29b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N1bWVudHMlMjBwYXBlcndvcmslMjBvZmZpY2V8ZW58MXx8fHwxNzc0Mjk1OTI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    title: "Turar Joy Topish",
    category: "Uy-joy",
    timeline: "Darhol",
    steps: [
      "Universitet yotoqxonasiga onlayn ariza bering",
      "Yoki xususiy turar joy qidiring (universitet e'lonlar taxtasi)",
      "Uylarni ko'ring va imkoniyatlarni tekshiring",
      "Ijara shartnomasini imzolang va depozit to'lang",
      "Manzilni mahalliy politsiyada ro'yxatdan o'tkazing (xorijiy talabalar uchun)",
    ],
    details: "Yotoqxona zamonaviy va qulay. Xususiy turar joy topish ham oson - universitet yaqinida ko'plab variantlar bor.",
    image: "https://images.unsplash.com/photo-1774078618445-ca7f78a2d830?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb3JtaXRvcnklMjBidWlsZGluZyUyMHJlc2lkZW50aWFsfGVufDF8fHx8MTc3NDQwOTQ4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "Bank Hisobi Ochish",
    category: "Moliya",
    timeline: "O'sha kun",
    steps: [
      "Talaba ID bilan universitet bankiga tashrif buyuring",
      "Pasport va yashash manzili tasdig'ini olib keling",
      "Hisob ochish formasini to'ldiring",
      "Dastlabki depozit qo'ying (minimal $10)",
      "Bank kartasi va hisob ma'lumotlarini oling",
    ],
    details: "Bank hisobi ochish juda oson va tez. O'sha kuni kartangizni olasiz. Bank xizmatlari talabalar uchun qulay.",
    image: "https://images.unsplash.com/photo-1770359718280-817b01057e02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5rJTIwYXRtJTIwYnVpbGRpbmd8ZW58MXx8fHwxNzc0NDA5NDgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    title: "Kursga Ro'yxatdan O'tish",
    category: "Akademik",
    timeline: "Semestrning birinchi haftasi",
    steps: [
      "Orientatsiya sessiyasida qatnashing",
      "Akademik maslahatchi bilan uchrashuv",
      "Kurslar katalogi va talablarini ko'rib chiqing",
      "Talabalar portalida onlayn kursga yoziling",
      "Jadvalingizni tasdiqlang va o'quv to'lovini to'lang",
    ],
    details: "Kursga yozilish onlayn tizim orqali oson amalga oshiriladi. Maslahatchi sizga to'g'ri kurslarni tanlashda yordam beradi.",
    image: "https://images.unsplash.com/photo-1547817752-c23df0357f18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBndWlkZXxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    title: "Tibbiy Sug'urta Olish",
    category: "Sog'liqni saqlash",
    timeline: "Birinchi oy",
    steps: [
      "Universitet tibbiy rejasi yoki xususiy sug'urta o'rtasida tanlang",
      "Tibbiy sug'urta arizasini topshiring",
      "Universitet klinikasida tibbiy ko'rikdan o'ting",
      "Sug'urta to'lovini to'lang",
      "Sug'urta kartasi va polis hujjatlarini oling",
    ],
    details: "Tibbiy sug'urta talabalar uchun majburiy. Universitet rejasi qulay va arzon. Barcha tibbiy xizmatlarni qamrab oladi.",
    image: "https://images.unsplash.com/photo-1764885415760-d3d8fff41fe3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMG1lZGljYWwlMjBjZW50ZXJ8ZW58MXx8fHwxNzc0MzQ4ODI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function AdvicesPage() {
  const [selectedAdvice, setSelectedAdvice] = useState<AdviceType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (advice: AdviceType) => {
    setSelectedAdvice(advice);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-yellow-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent mb-4">
              Yangi Talabalar Uchun Maslahatlar
            </h1>
            <p className="text-xl text-gray-300">
              Yangi va xorijiy talabalar uchun qadam-baqadam qo'llanmalar
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {advices.map((advice, index) => (
            <motion.div
              key={advice.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-yellow-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-yellow-500/20"
                onClick={() => handleCardClick(advice)}
              >
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={advice.image}
                    alt={advice.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-yellow-600/80 via-yellow-600/40 to-transparent group-hover:from-yellow-500/90 transition-all duration-500" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-yellow-600 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                      {advice.category}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Lightbulb className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-yellow-400 transition-colors">
                    {advice.title}
                  </h3>
                  
                  <div className="flex items-center gap-2 mb-3">
                    <Clock className="size-4 text-yellow-400" />
                    <p className="text-sm text-gray-300">
                      <span className="font-medium">Muddat:</span> {advice.timeline}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm text-gray-400 line-clamp-2">
                      {advice.steps.length} ta qadam
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedAdvice && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                  {selectedAdvice.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-64 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedAdvice.image}
                    alt={selectedAdvice.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-yellow-600 text-white px-4 py-2 rounded-full backdrop-blur-sm">
                      {selectedAdvice.category}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                  <Clock className="size-5 text-yellow-400" />
                  <div>
                    <p className="text-sm text-gray-400">Muddat</p>
                    <p className="text-gray-300">{selectedAdvice.timeline}</p>
                  </div>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-gray-300 leading-relaxed">{selectedAdvice.details}</p>
                </div>

                <div className="bg-white/5 rounded-xl p-6 border border-white/10">
                  <div className="flex items-center gap-2 mb-4">
                    <FileText className="size-5 text-yellow-400" />
                    <p className="text-gray-300">Bajarilishi kerak bo'lgan qadamlar:</p>
                  </div>
                  <ol className="space-y-3">
                    {selectedAdvice.steps.map((step, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.1 }}
                        className="flex items-start gap-3"
                      >
                        <CheckCircle className="size-5 text-green-400 mt-0.5 flex-shrink-0" />
                        <div>
                          <span className="text-yellow-400 font-medium">{index + 1}. </span>
                          <span className="text-gray-300">{step}</span>
                        </div>
                      </motion.li>
                    ))}
                  </ol>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
