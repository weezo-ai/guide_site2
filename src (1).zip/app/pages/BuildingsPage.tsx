import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, MapPin, Building } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface BuildingType {
  id: number;
  name: string;
  location: string;
  address: string;
  floors: string;
  description: string;
  details: string;
  coordinates: string;
  image: string;
}

const buildings: BuildingType[] = [
  {
    id: 1,
    name: "Asosiy Akademik Bino",
    location: "Kampus Markazi, A Bino",
    address: "Universitet ko'chasi, 123",
    floors: "5 qavat",
    description: "Ko'pchilik ma'ruza xonalari va ma'muriy ofislar",
    details: "Bu bino universitetning asosiy akademik binosi bo'lib, barcha asosiy ma'ruza xonalari, seminar xonalari va ma'muriy ofislar joylashgan. Binoda zamonaviy texnologiyalar, multimedia qurilmalari va qulayliklar mavjud.",
    coordinates: "41.3111,69.2797",
    image: "https://images.unsplash.com/photo-1719342399567-4b31027198b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYnVpbGRpbmclMjBjYW1wdXN8ZW58MXx8fHwxNzc0Mzg4NjU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    name: "Fan Laboratoriyasi Binosi",
    location: "Shimoliy Kampus, C Bino",
    address: "Tadqiqot ko'chasi, 456",
    floors: "4 qavat",
    description: "Fizika, kimyo va biologiya uchun zamonaviy laboratoriyalar",
    details: "Zamonaviy laboratoriya jihozlari bilan jihozlangan. Fizika, kimyo va biologiya fanlari uchun maxsus laboratoriyalar, tadqiqot xonalari va ilmiy tajriba o'tkazish uchun joy mavjud.",
    coordinates: "41.3125,69.2810",
    image: "https://images.unsplash.com/photo-1675583152779-9fe454abe3a4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY2llbmNlJTIwbGFib3JhdG9yeSUyMGJ1aWxkaW5nfGVufDF8fHx8MTc3NDM2NTg1Mnww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    name: "Universitet Kutubxonasi",
    location: "Sharqiy Kampus, L Bino",
    address: "Bilim ko'chasi, 789",
    floors: "6 qavat",
    description: "Keng kutubxona to'plami va o'qish xonalari",
    details: "Keng kitoblar to'plami, raqamli resurslar, tinch o'qish xonalari va guruh ishlash uchun xonalar mavjud. 24/7 ishlaydi va barcha talabalar uchun bepul.",
    coordinates: "41.3100,69.2825",
    image: "https://images.unsplash.com/photo-1770721474021-70f69ddecb46?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsaWJyYXJ5JTIwYWNhZGVtaWMlMjBidWlsZGluZ3xlbnwxfHx8fDE3NzQ0MDk0NzZ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    name: "Ma'ruza Zali Majmuasi",
    location: "Markaziy Kampus, D Bino",
    address: "Akademik yo'li, 321",
    floors: "3 qavat",
    description: "Seminarlar va konferentsiyalar uchun katta auditoriyalar",
    details: "Yirik tadbirlar, seminarlar va konferentsiyalar uchun mo'ljallangan zamonaviy auditoriyalar. Yuqori sifatli audio-video texnologiyalari bilan jihozlangan.",
    coordinates: "41.3115,69.2800",
    image: "https://images.unsplash.com/photo-1606761568499-6d2451b23c66?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwbGVjdHVyZSUyMGhhbGx8ZW58MXx8fHwxNzc0MzMzNjM0fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    name: "Talabalar Turar Joyi",
    location: "G'arbiy Kampus, R Bino",
    address: "Yashash joyi ko'chasi, 555",
    floors: "8 qavat",
    description: "Umumiy qulayliklar bilan zamonaviy talabalar turar joyi",
    details: "Zamonaviy xonalar, umumiy oshxona, o'qish xonalari, sport zali va dam olish joylari. Xavfsizlik 24/7 ta'minlangan.",
    coordinates: "41.3090,69.2780",
    image: "https://images.unsplash.com/photo-1774078618445-ca7f78a2d830?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb3JtaXRvcnklMjBidWlsZGluZyUyMHJlc2lkZW50aWFsfGVufDF8fHx8MTc3NDQwOTQ4NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    name: "Talabalar Markazi",
    location: "Kampus Markazi, S Bino",
    address: "Talabalar maydoni, 111",
    floors: "2 qavat",
    description: "Dam olish, ovqatlanish va talabalar faoliyati markazi",
    details: "Talabalar uchun dam olish, ovqatlanish, sport mashg'ulotlari va ijtimoiy tadbirlar o'tkazish uchun mo'ljallangan zamonaviy markaz.",
    coordinates: "41.3108,69.2795",
    image: "https://images.unsplash.com/photo-1670348060135-d4c6662b4138?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwY2FmZXRlcmlhJTIwcmVzdGF1cmFudHxlbnwxfHx8fDE3NzQ0MDk0Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function BuildingsPage() {
  const [selectedBuilding, setSelectedBuilding] = useState<BuildingType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (building: BuildingType) => {
    setSelectedBuilding(building);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent mb-4">
              Binolar va Joylashuvi
            </h1>
            <p className="text-xl text-gray-300">
              Kampusdagi barcha akademik binolarni toping
            </p>
          </motion.div>
        </div>
      </header>

      {/* Buildings Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {buildings.map((building, index) => (
            <motion.div
              key={building.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-blue-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-blue-500/20"
                onClick={() => handleCardClick(building)}
              >
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={building.image}
                    alt={building.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-blue-600/80 via-blue-600/40 to-transparent group-hover:from-blue-500/90 transition-all duration-500" />
                  <div className="absolute bottom-4 left-4">
                    <Building className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-blue-400 transition-colors">
                    {building.name}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <MapPin className="size-4 text-blue-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-300">{building.location}</p>
                        <p className="text-sm text-gray-400">{building.address}</p>
                      </div>
                    </div>
                    <p className="text-sm text-gray-400">{building.floors}</p>
                    <p className="text-sm text-gray-300 mt-3">{building.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Modal Dialog */}
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedBuilding && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                  {selectedBuilding.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                {/* Image */}
                <div className="relative h-80 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedBuilding.image}
                    alt={selectedBuilding.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>

                {/* Information */}
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="size-5 text-blue-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-gray-300">{selectedBuilding.location}</p>
                      <p className="text-gray-400">{selectedBuilding.address}</p>
                      <p className="text-gray-400 mt-1">{selectedBuilding.floors}</p>
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <p className="text-gray-300 leading-relaxed">{selectedBuilding.details}</p>
                  </div>

                  {/* Google Map */}
                  <div className="rounded-xl overflow-hidden border border-white/20">
                    <iframe
                      width="100%"
                      height="400"
                      frameBorder="0"
                      style={{ border: 0 }}
                      src={`https://www.google.com/maps?q=${selectedBuilding.coordinates}&output=embed`}
                      allowFullScreen
                    ></iframe>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
