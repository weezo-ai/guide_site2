import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, Calendar as CalendarIcon, Clock, MapPin } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface EventType {
  id: number;
  title: string;
  type: string;
  date: string;
  time: string;
  location: string;
  description: string;
  details: string;
  image: string;
}

const events: EventType[] = [
  {
    id: 1,
    title: "Orientatsiya Haftasi",
    type: "Tadbir",
    date: "1-5 Sentyabr, 2026",
    time: "9:00 - 17:00",
    location: "Asosiy Kampus",
    description: "Yangi talabalar uchun kampus sayohati, ro'yxatdan o'tish va ijtimoiy tadbirlar",
    details: "Yangi talabalarni universitega xush kelibsiz aytish, kampusni tanishish, ro'yxatdan o'tish jarayonlari va ijtimoiy tadbirlar. Barcha yangi talabalar uchun majburiy.",
    image: "https://images.unsplash.com/photo-1591218214141-45545921d2d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGV2ZW50fGVufDF8fHx8MTc3NDQwOTQ3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    title: "Oraliq Imtihonlar",
    type: "Imtihon",
    date: "15-20 Aprel, 2026",
    time: "Imtihon jadvaliga ko'ra",
    location: "Turli Ma'ruza Xonalari",
    description: "Barcha kurslar bo'yicha yarim semestr imtihonlari",
    details: "Yarim semestr imtihonlari. Aniq jadvallarni talabalar portalida tekshiring. Imtihonlarga yaxshi tayyorlaning.",
    image: "https://images.unsplash.com/photo-1758685848208-e108b6af94cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGFtJTIwdGVzdCUyMHByZXBhcmF0aW9ufGVufDF8fHx8MTc3NDQwOTQ4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    title: "Xalqaro Talabalar Festivali",
    type: "Tadbir",
    date: "10 May, 2026",
    time: "14:00 - 20:00",
    location: "Talabalar Markazi Maydoni",
    description: "Madaniy ko'rsatuvlar, xalqaro taomlar va ko'rgazmalar bilan xilma-xillikni nishonlash",
    details: "Turli mamlakatlardan kelgan talabalar o'z madaniyatlarini ko'rsatadilar. Milliy taomlar, an'anaviy kiyimlar, musiqiy ko'rsatuvlar va raqs ijrolari.",
    image: "https://images.unsplash.com/photo-1591218214141-45545921d2d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGV2ZW50fGVufDF8fHx8MTc3NDQwOTQ3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "Yakuniy Imtihonlar",
    type: "Imtihon",
    date: "1-15 Iyun, 2026",
    time: "Imtihon jadvaliga ko'ra",
    location: "Turli Ma'ruza Xonalari",
    description: "Semestr oxiridagi yakuniy imtihonlar",
    details: "Semestr yakuniy imtihonlari. Batafsil jadval uchun akademik kalendarga qarang. Imtihonlarga yaxshi tayyorlaning.",
    image: "https://images.unsplash.com/photo-1758685848208-e108b6af94cc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxleGFtJTIwdGVzdCUyMHByZXBhcmF0aW9ufGVufDF8fHx8MTc3NDQwOTQ4M3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    title: "Karyera Yarmarkasi",
    type: "Tadbir",
    date: "15 Mart, 2026",
    time: "10:00 - 16:00",
    location: "Sport Majmuasi",
    description: "Potentsial ish beruvchilar bilan tanishish, ish imkoniyatlarini o'rganish",
    details: "Yirik kompaniyalar va ish beruvchilar bilan to'g'ridan-to'g'ri uchrashish. CV tayyorlash, suhbat ko'nikmalari bo'yicha seminarlar.",
    image: "https://images.unsplash.com/photo-1591218214141-45545921d2d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGV2ZW50fGVufDF8fHx8MTc3NDQwOTQ3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    title: "Bitiruv Marosimi",
    type: "Tadbir",
    date: "20 Iyul, 2026",
    time: "10:00 - 14:00",
    location: "Asosiy Auditoriya",
    description: "Bitiruvchi talabalarning yutuqlarini nishonlash tantanasi",
    details: "Rasmiy bitiruv marosimi. Diplomlar topshirish, rasmiy nutqlar va nishonlash. Oila a'zolarini taklif qilishingiz mumkin.",
    image: "https://images.unsplash.com/photo-1591218214141-45545921d2d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGV2ZW50fGVufDF8fHx8MTc3NDQwOTQ3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 7,
    title: "Ro'yxatdan O'tish Muddati",
    type: "Muhlik",
    date: "25 Avgust, 2026",
    time: "17:00",
    location: "Onlayn Portal",
    description: "Kuz semestri kurslari uchun ro'yxatdan o'tishning oxirgi kuni",
    details: "Kuz semestri kurslariga yozilishning oxirgi muddati. Kechikkan ro'yxatdan o'tish qo'shimcha to'lovlarni talab qiladi.",
    image: "https://images.unsplash.com/photo-1771758249853-415175dc29b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N1bWVudHMlMjBwYXBlcndvcmslMjBvZmZpY2V8ZW58MXx8fHwxNzc0Mjk1OTI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 8,
    title: "Qishki Ta'til",
    type: "Bayram",
    date: "20 Dekabr, 2026 - 5 Yanvar, 2027",
    time: "Kun bo'yi",
    location: "Kampus Yopiq",
    description: "Qishki bayramlar uchun universitet yopiladi",
    details: "Universitet qishki bayramlar uchun yopiq. Kampus ob'ektlari 6 Yanvar, 2027 dan qayta ochiladi.",
    image: "https://images.unsplash.com/photo-1547817752-c23df0357f18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBndWlkZXxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function EventsPage() {
  const [selectedEvent, setSelectedEvent] = useState<EventType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (event: EventType) => {
    setSelectedEvent(event);
    setIsOpen(true);
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Imtihon":
        return "bg-red-600";
      case "Muhlik":
        return "bg-orange-600";
      case "Bayram":
        return "bg-blue-600";
      default:
        return "bg-green-600";
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-pink-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent mb-4">
              Tadbirlar va Imtihonlar
            </h1>
            <p className="text-xl text-gray-300">
              Muhim sanalar va akademik kalendar
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {events.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-pink-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-pink-500/20"
                onClick={() => handleCardClick(event)}
              >
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={event.image}
                    alt={event.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-pink-600/80 via-pink-600/40 to-transparent group-hover:from-pink-500/90 transition-all duration-500" />
                  <div className="absolute top-4 right-4">
                    <span className={`${getTypeColor(event.type)} text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm`}>
                      {event.type}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <CalendarIcon className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-pink-400 transition-colors">
                    {event.title}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <CalendarIcon className="size-4 text-pink-400 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{event.date}</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="size-4 text-pink-400 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{event.time}</p>
                    </div>
                    <p className="text-sm text-gray-400 mt-3 line-clamp-2">{event.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedEvent && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-pink-400 to-rose-400 bg-clip-text text-transparent">
                  {selectedEvent.title}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-80 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedEvent.image}
                    alt={selectedEvent.title}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className={`${getTypeColor(selectedEvent.type)} text-white px-4 py-2 rounded-full backdrop-blur-sm`}>
                      {selectedEvent.type}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                    <CalendarIcon className="size-5 text-pink-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Sana</p>
                      <p className="text-gray-300">{selectedEvent.date}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                    <Clock className="size-5 text-pink-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Vaqt</p>
                      <p className="text-gray-300">{selectedEvent.time}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10 md:col-span-2">
                    <MapPin className="size-5 text-pink-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Joylashuv</p>
                      <p className="text-gray-300">{selectedEvent.location}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-sm text-gray-400 mb-2">Ta'rif</p>
                  <p className="text-gray-300 leading-relaxed mb-3">{selectedEvent.description}</p>
                  <p className="text-gray-400 leading-relaxed">{selectedEvent.details}</p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
