import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Input } from "../components/ui/input";
import { Search, Building2, Store, Users, Bus, Lightbulb, Calendar, BookOpen } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { motion } from "motion/react";

const categories = [
  {
    id: 1,
    title: "Binolar va Joylashuvi",
    description: "Barcha akademik binolar va ularning kampusdagi joylashuvi",
    icon: Building2,
    link: "/buildings",
    gradient: "from-blue-500 to-cyan-400",
    image: "https://images.unsplash.com/photo-1719342399567-4b31027198b6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwYnVpbGRpbmclMjBjYW1wdXN8ZW58MXx8fHwxNzc0Mzg4NjU1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    title: "Boshqa Binolar",
    description: "Kafeler, do'konlar, banklar, shifoxonalar va boshqalar",
    icon: Store,
    link: "/other-buildings",
    gradient: "from-purple-500 to-pink-400",
    image: "https://images.unsplash.com/photo-1670348060135-d4c6662b4138?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwY2FmZXRlcmlhJTIwcmVzdGF1cmFudHxlbnwxfHx8fDE3NzQ0MDk0Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    title: "O'qituvchilar",
    description: "O'qituvchilar bilan tanishing",
    icon: Users,
    link: "/teachers",
    gradient: "from-orange-500 to-red-400",
    image: "https://images.unsplash.com/photo-1758270704925-fa59d93119c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFjaGVyJTIwcHJvZmVzc29yJTIwY2xhc3Nyb29tfGVufDF8fHx8MTc3NDMwNTE1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    title: "Fanlar",
    description: "O'qitiladigan fanlarni o'rganing",
    icon: BookOpen,
    link: "/subjects",
    gradient: "from-green-500 to-emerald-400",
    image: "https://images.unsplash.com/photo-1547817752-c23df0357f18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBndWlkZXxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    title: "Foydali Yo'nalishlar",
    description: "Barcha transport turlari va ularning narxlari",
    icon: Bus,
    link: "/transport",
    gradient: "from-indigo-500 to-blue-400",
    image: "https://images.unsplash.com/photo-1543698376-9c76b08cd35d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjBidXMlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    title: "Yangi Talabalar Uchun Maslahatlar",
    description: "Muhim qo'llanmalar va ko'rsatmalar",
    icon: Lightbulb,
    link: "/advices",
    gradient: "from-yellow-500 to-orange-400",
    image: "https://images.unsplash.com/photo-1547817752-c23df0357f18?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwc3R1ZHlpbmclMjBndWlkZXxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 7,
    title: "Tadbirlar va Imtihonlar",
    description: "Muhim sanalar va akademik tadbirlar",
    icon: Calendar,
    link: "/events",
    gradient: "from-pink-500 to-rose-400",
    image: "https://images.unsplash.com/photo-1591218214141-45545921d2d9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1bml2ZXJzaXR5JTIwZ3JhZHVhdGlvbiUyMGV2ZW50fGVufDF8fHx8MTc3NDQwOTQ3OXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<string[]>([]);

  const handleSearch = (query: string) => {
    setSearchQuery(query);
    
    if (query.trim() === "") {
      setSearchResults([]);
      return;
    }

    const results: string[] = [];
    const lowerQuery = query.toLowerCase();

    categories.forEach((category) => {
      if (
        category.title.toLowerCase().includes(lowerQuery) ||
        category.description.toLowerCase().includes(lowerQuery)
      ) {
        results.push(`${category.title} - ${category.description}`);
      }
    });

    const searchableContent = [
      { key: "kutubxona", value: "Kutubxona - Asosiy Bino, 3-qavat" },
      { key: "oshxona", value: "Talabalar Oshxonasi - A Bino, Birinchi qavat" },
      { key: "hujjatlar", value: "Hujjatlarni rasmiylashtirish - Ma'muriy ofis" },
      { key: "viza", value: "Viza uzaytirish - Xorijiy talabalar bo'limi" },
      { key: "avtobus", value: "24-avtobus yo'nalishi - $1.50 kampusgacha" },
      { key: "metro", value: "Metro 2-liniya - $2.00, eng yaqin bekat Markaziy" },
      { key: "matematika", value: "Matematika - Prof. Johnson, 301-xona" },
      { key: "fizika", value: "Fizika - Dr. Chen, Laboratoriya binosi" },
    ];

    searchableContent.forEach((item) => {
      if (item.key.toLowerCase().includes(lowerQuery)) {
        results.push(item.value);
      }
    });

    setSearchResults(results);
  };

  return (
    <div className="min-h-screen bg-black">
      {/* Hero Header */}
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <h1 className="text-5xl sm:text-7xl bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent mb-6">
              Talabalar Qo'llanmasi
            </h1>
            <p className="text-xl sm:text-2xl text-gray-300 max-w-3xl mx-auto">
              Kampus hayotiga to'liq qo'llanma
            </p>
          </motion.div>
        </div>
      </header>

      {/* Search Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative"
        >
          <div className="relative backdrop-blur-xl bg-white/10 rounded-2xl border border-white/20 shadow-2xl">
            <Search className="absolute left-6 top-1/2 transform -translate-y-1/2 text-gray-400 size-6" />
            <Input
              type="text"
              placeholder="Binolar, o'qituvchilar, transport yoki ma'lumotlarni qidiring..."
              className="pl-16 pr-6 py-8 w-full bg-transparent border-0 text-white placeholder:text-gray-400 text-lg focus-visible:ring-2 focus-visible:ring-purple-500"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>

          {/* Search Results */}
          {searchResults.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4"
            >
              <Card className="backdrop-blur-xl bg-white/10 border-white/20 shadow-2xl">
                <CardContent className="p-6">
                  <p className="text-white mb-4">Qidiruv natijalari:</p>
                  <ul className="space-y-2">
                    {searchResults.map((result, index) => (
                      <motion.li
                        key={index}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                        className="p-4 hover:bg-white/10 rounded-xl cursor-pointer transition-all text-gray-200"
                      >
                        {result}
                      </motion.li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Category Cards Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {categories.map((category, index) => {
            const Icon = category.icon;
            return (
              <motion.div
                key={category.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <Link to={category.link}>
                  <Card className="h-full overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-white/40 transition-all duration-500 group hover:scale-105 hover:shadow-2xl">
                    <div className="relative h-64 overflow-hidden">
                      <ImageWithFallback
                        src={category.image}
                        alt={category.title}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-t ${category.gradient} opacity-60 group-hover:opacity-80 transition-opacity duration-500`} />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
                      <div className="absolute bottom-6 left-6 text-white">
                        <Icon className="size-12 mb-2 drop-shadow-lg" />
                      </div>
                    </div>
                    <CardContent className="p-8">
                      <h3 className="text-2xl mb-3 text-white group-hover:text-transparent group-hover:bg-gradient-to-r group-hover:from-white group-hover:to-gray-300 group-hover:bg-clip-text transition-all duration-300">
                        {category.title}
                      </h3>
                      <p className="text-gray-300">{category.description}</p>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
