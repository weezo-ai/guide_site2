import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, MapPin, Clock, Store as StoreIcon } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface OtherBuildingType {
  id: number;
  name: string;
  category: string;
  location: string;
  hours: string;
  description: string;
  details: string;
  coordinates: string;
  image: string;
}

const otherBuildings: OtherBuildingType[] = [
  {
    id: 1,
    name: "Kampus Kafesi",
    category: "Oziq-ovqat",
    location: "Talabalar Markazi, Birinchi qavat",
    hours: "7:00 - 22:00",
    description: "Kofe, gazaklar va yengil taomlar",
    details: "Zamonaviy kafe talabalar uchun turli xil qahva, choy, shirinliklar va tez tayyorlanadigan taomlar taklif etadi. Wi-Fi va qulay o'tirish joylari mavjud.",
    coordinates: "41.3108,69.2795",
    image: "https://images.unsplash.com/photo-1604552584409-44de624c9f57?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2ZmZWUlMjBzaG9wJTIwY2FmZXxlbnwxfHx8fDE3NzQ0MDk0Nzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    name: "Talabalar Oshxonasi",
    category: "Oziq-ovqat",
    location: "Asosiy Bino, 1-qavat",
    hours: "8:00 - 20:00",
    description: "Arzon kundalik taomlar va xalqaro oshxona",
    details: "Talabalar uchun arzon narxlarda to'yimli va mazali taomlar. O'zbek, rus, koreys va boshqa xalqaro taomlar taklif etiladi.",
    coordinates: "41.3111,69.2797",
    image: "https://images.unsplash.com/photo-1670348060135-d4c6662b4138?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHVkZW50JTIwY2FmZXRlcmlhJTIwcmVzdGF1cmFudHxlbnwxfHx8fDE3NzQ0MDk0Nzd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    name: "Kampus Supermarketi",
    category: "Do'kon",
    location: "Asosiy darvozadan 500m",
    hours: "6:00 - 23:00",
    description: "Oziq-ovqat, kantselyariya va kundalik ehtiyojlar",
    details: "Keng assortimentdagi oziq-ovqat mahsulotlari, kantselyariya buyumlari, gigiyena vositalari va kundalik hayot uchun zarur narsalar.",
    coordinates: "41.3105,69.2785",
    image: "https://images.unsplash.com/photo-1698466632388-77a7495b89b5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdXBlcm1hcmtldCUyMGdyb2NlcnklMjBzdG9yZXxlbnwxfHx8fDE3NzQ0MDk0ODB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    name: "Universitet Banki",
    category: "Moliyaviy xizmatlar",
    location: "Ma'muriy Bino, 1-qavat",
    hours: "9:00 - 17:00 (Dush-Jum)",
    description: "Bank xizmatlari va bankomat 24/7",
    details: "To'liq bank xizmatlari, hisob ochish, pul o'tkazmalari va moliyaviy maslahatlar. Bankomat 24 soat ishlaydi.",
    coordinates: "41.3112,69.2798",
    image: "https://images.unsplash.com/photo-1770359718280-817b01057e02?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYW5rJTIwYXRtJTIwYnVpbGRpbmd8ZW58MXx8fHwxNzc0NDA5NDgwfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    name: "Tibbiy Markaz",
    category: "Sog'liqni saqlash",
    location: "Salomatlik Binosi, Sport majmuasi yonida",
    hours: "24/7 Tez yordam xizmati",
    description: "Talabalar uchun umumiy tibbiy yordam va tez yordam xizmatlari",
    details: "Malakali shifokorlar, tez yordam xizmati, laboratoriya tekshiruvlari va talabalar uchun bepul tibbiy yordam.",
    coordinates: "41.3095,69.2805",
    image: "https://images.unsplash.com/photo-1764885415760-d3d8fff41fe3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxob3NwaXRhbCUyMG1lZGljYWwlMjBjZW50ZXJ8ZW58MXx8fHwxNzc0MzQ4ODI5fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    name: "Xorijiy Talabalar Bo'limi",
    category: "Talabalar xizmati",
    location: "Ma'muriy Bino, 2-qavat",
    hours: "9:00 - 17:00 (Dush-Jum)",
    description: "Viza yordami, turar joy va madaniy integratsiya",
    details: "Xorijiy talabalar uchun viza masalalari, turar joy topishda yordam, madaniy moslashish va har qanday muammolarda ko'mak.",
    coordinates: "41.3112,69.2798",
    image: "https://images.unsplash.com/photo-1771758249853-415175dc29b9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkb2N1bWVudHMlMjBwYXBlcndvcmslMjBvZmZpY2V8ZW58MXx8fHwxNzc0Mjk1OTI3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function OtherBuildingsPage() {
  const [selectedBuilding, setSelectedBuilding] = useState<OtherBuildingType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (building: OtherBuildingType) => {
    setSelectedBuilding(building);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
              Boshqa Binolar
            </h1>
            <p className="text-xl text-gray-300">
              Kampus atrofidagi muhim xizmatlar va ob'ektlar
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {otherBuildings.map((building, index) => (
            <motion.div
              key={building.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-purple-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/20"
                onClick={() => handleCardClick(building)}
              >
                <div className="relative h-64 overflow-hidden">
                  <ImageWithFallback
                    src={building.image}
                    alt={building.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-purple-600/80 via-purple-600/40 to-transparent group-hover:from-purple-500/90 transition-all duration-500" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-purple-600 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                      {building.category}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <StoreIcon className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-purple-400 transition-colors">
                    {building.name}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-start gap-2">
                      <MapPin className="size-4 text-purple-400 mt-1 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{building.location}</p>
                    </div>
                    <div className="flex items-start gap-2">
                      <Clock className="size-4 text-purple-400 mt-1 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{building.hours}</p>
                    </div>
                    <p className="text-sm text-gray-300 mt-3">{building.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedBuilding && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  {selectedBuilding.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-80 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedBuilding.image}
                    alt={selectedBuilding.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-purple-600 text-white px-4 py-2 rounded-full backdrop-blur-sm">
                      {selectedBuilding.category}
                    </span>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <MapPin className="size-5 text-purple-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Manzil</p>
                        <p className="text-gray-300">{selectedBuilding.location}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <Clock className="size-5 text-purple-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Ish vaqti</p>
                        <p className="text-gray-300">{selectedBuilding.hours}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <p className="text-gray-300 leading-relaxed">{selectedBuilding.details}</p>
                  </div>

                  <div className="rounded-xl overflow-hidden border border-white/20">
                    <iframe
                      width="100%"
                      height="400"
                      frameBorder="0"
                      style={{ border: 0 }}
                      src={`https://www.google.com/maps?q=${selectedBuilding.coordinates}&output=embed`}
                      allowFullScreen
                    ></iframe>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
