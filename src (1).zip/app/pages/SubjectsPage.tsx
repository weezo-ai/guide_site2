import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, BookOpen, Clock, GraduationCap, FileText } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface SubjectType {
  id: number;
  name: string;
  code: string;
  credits: number;
  semester: string;
  description: string;
  syllabus: string[];
  prerequisites: string;
  image: string;
}

const subjects: SubjectType[] = [
  {
    id: 1,
    name: "Oliy Matematika",
    code: "MATH301",
    credits: 4,
    semester: "1-semestr",
    description: "Integral va differensial hisob, chiziqli algebra va matematik tahlil asoslari",
    syllabus: [
      "Limitlar va uzluksizlik",
      "Hosilalar va differensiallar",
      "Integrallar va ularning qo'llanilishi",
      "Chiziqli algebra elementlari",
      "Differensial tenglamalar",
    ],
    prerequisites: "Asosiy matematika",
    image: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=1080",
  },
  {
    id: 2,
    name: "Fizika",
    code: "PHYS201",
    credits: 4,
    semester: "1-semestr",
    description: "Klassik mexanika, termodinamika va elektromagnetizm asoslari",
    syllabus: [
      "Nyuton qonunlari va mexanika",
      "Issiqlik va termodinamika",
      "Elektr va magnetizm",
      "To'lqinlar va optika",
      "Zamonaviy fizika kiritma",
    ],
    prerequisites: "Asosiy fizika",
    image: "https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=1080",
  },
  {
    id: 3,
    name: "Dasturlash Asoslari",
    code: "CS101",
    credits: 3,
    semester: "1-semestr",
    description: "Python dasturlash tili orqali dasturlash asoslari",
    syllabus: [
      "Dasturlash asoslari va sintaksis",
      "Ma'lumotlar turlari va operatorlar",
      "Funksiyalar va modullar",
      "Obyektga yo'naltirilgan dasturlash",
      "Algoritmlar va ma'lumotlar tuzilmalari",
    ],
    prerequisites: "Yo'q",
    image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?w=1080",
  },
  {
    id: 4,
    name: "Ingliz Tili",
    code: "ENG102",
    credits: 3,
    semester: "1-2 semestr",
    description: "Akademik ingliz tili va kommunikatsiya ko'nikmalari",
    syllabus: [
      "Grammatika va lug'at",
      "O'qish va tushunish",
      "Yozish ko'nikmalari",
      "Gapirish va tinglab tushunish",
      "Akademik prezentatsiyalar",
    ],
    prerequisites: "Asosiy ingliz tili",
    image: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?w=1080",
  },
  {
    id: 5,
    name: "Kimyo",
    code: "CHEM201",
    credits: 4,
    semester: "2-semestr",
    description: "Umumiy, organik va noorganik kimyo asoslari",
    syllabus: [
      "Atom tuzilishi va davriy sistema",
      "Kimyoviy bog'lanishlar",
      "Organik birikmalar",
      "Kimyoviy reaksiyalar kinetikasi",
      "Laboratoriya tajribalari",
    ],
    prerequisites: "Asosiy kimyo",
    image: "https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?w=1080",
  },
  {
    id: 6,
    name: "Tarix",
    code: "HIST101",
    credits: 3,
    semester: "1-semestr",
    description: "O'zbekiston va jahon tarixi, madaniyat va sivilizatsiyalar",
    syllabus: [
      "Qadimgi sivilizatsiyalar",
      "O'rta asrlar tarixi",
      "Yangi davr va renessans",
      "XX asr voqealari",
      "Mustaqillik davri",
    ],
    prerequisites: "Yo'q",
    image: "https://images.unsplash.com/photo-1461360370896-922624d12aa1?w=1080",
  },
  {
    id: 7,
    name: "Ma'lumotlar Bazasi",
    code: "CS301",
    credits: 3,
    semester: "3-semestr",
    description: "Relatsion ma'lumotlar bazalari va SQL dasturlash",
    syllabus: [
      "Ma'lumotlar bazasi kontseptsiyalari",
      "Relatsion model va SQL",
      "Ma'lumotlar bazasi dizayni",
      "Indekslash va optimizatsiya",
      "Amaliy loyihalar",
    ],
    prerequisites: "Dasturlash asoslari",
    image: "https://images.unsplash.com/photo-1544383835-bda2bc66a55d?w=1080",
  },
  {
    id: 8,
    name: "Sun'iy Intellekt",
    code: "CS401",
    credits: 4,
    semester: "4-semestr",
    description: "Mashina o'rganish va sun'iy intellekt asoslari",
    syllabus: [
      "AI ga kirish",
      "Mashina o'rganish algoritmlari",
      "Neyron tarmoqlar",
      "Chuqur o'rganish",
      "AI amaliy qo'llanmalari",
    ],
    prerequisites: "Python dasturlash, Matematika",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1080",
  },
];

export default function SubjectsPage() {
  const [selectedSubject, setSelectedSubject] = useState<SubjectType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (subject: SubjectType) => {
    setSelectedSubject(subject);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-green-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent mb-4">
              Fanlar
            </h1>
            <p className="text-xl text-gray-300">
              O'qitiladigan fanlar va dasturlar
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {subjects.map((subject, index) => (
            <motion.div
              key={subject.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-green-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-green-500/20"
                onClick={() => handleCardClick(subject)}
              >
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={subject.image}
                    alt={subject.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-green-600/80 via-green-600/40 to-transparent group-hover:from-green-500/90 transition-all duration-500" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                      {subject.code}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <BookOpen className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-green-400 transition-colors">
                    {subject.name}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <GraduationCap className="size-4 text-green-400" />
                      <p className="text-sm text-gray-300">{subject.credits} kredit</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="size-4 text-green-400" />
                      <p className="text-sm text-gray-300">{subject.semester}</p>
                    </div>
                    <p className="text-sm text-gray-400 mt-3">{subject.description}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedSubject && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">
                  {selectedSubject.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-64 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedSubject.image}
                    alt={selectedSubject.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-green-600 text-white px-4 py-2 rounded-full backdrop-blur-sm">
                      {selectedSubject.code}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <GraduationCap className="size-6 text-green-400 mb-2" />
                    <p className="text-sm text-gray-400">Kreditlar</p>
                    <p className="text-xl text-white">{selectedSubject.credits}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <Clock className="size-6 text-green-400 mb-2" />
                    <p className="text-sm text-gray-400">Semestr</p>
                    <p className="text-xl text-white">{selectedSubject.semester}</p>
                  </div>
                  <div className="bg-white/5 rounded-xl p-4 border border-white/10 col-span-2 md:col-span-1">
                    <FileText className="size-6 text-green-400 mb-2" />
                    <p className="text-sm text-gray-400">Talablar</p>
                    <p className="text-sm text-white">{selectedSubject.prerequisites}</p>
                  </div>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-sm text-gray-400 mb-2">Ta'rif</p>
                  <p className="text-gray-300 leading-relaxed">{selectedSubject.description}</p>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-sm text-gray-400 mb-3">O'quv dasturi:</p>
                  <ul className="space-y-2">
                    {selectedSubject.syllabus.map((item, index) => (
                      <li key={index} className="flex items-start gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-green-600/30 text-green-400 flex items-center justify-center text-sm">
                          {index + 1}
                        </span>
                        <span className="text-gray-300 pt-0.5">{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
