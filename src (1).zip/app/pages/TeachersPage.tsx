import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, Mail, MapPin, BookOpen, Phone } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface TeacherType {
  id: number;
  name: string;
  subject: string;
  department: string;
  office: string;
  email: string;
  phone: string;
  officeHours: string;
  bio: string;
  image: string;
}

const teachers: TeacherType[] = [
  {
    id: 1,
    name: "Dr. Sardor Rahimov",
    subject: "Matematika",
    department: "Fan Fakulteti",
    office: "A Bino, 301-xona",
    email: "s.rahimov@universitet.uz",
    phone: "+998 90 123 45 67",
    officeHours: "Dush, Chor 14:00-16:00",
    bio: "15 yillik tajribaga ega matematika professori. Oliy matematika va matematik tahlil bo'yicha mutaxassis. Xalqaro konferentsiyalarda ko'plab maqolalar nashr etgan.",
    image: "https://images.unsplash.com/flagged/photo-1559475555-b26777ed3ab4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwdGVhY2hlciUyMGNsYXNzcm9vbXxlbnwxfHx8fDE3NzQ0MDk0ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    name: "Prof. Li Chen",
    subject: "Fizika",
    department: "Fan Fakulteti",
    office: "Laboratoriya Binosi, 205-xona",
    email: "l.chen@universitet.uz",
    phone: "+998 90 234 56 78",
    officeHours: "Sesh, Pay 15:00-17:00",
    bio: "Nazariy va amaliy fizika bo'yicha professor. Kvant mexanikasi va zarralar fizikasi mutaxassisi. 20 yildan ortiq tajriba.",
    image: "https://images.unsplash.com/flagged/photo-1559475555-b26777ed3ab4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwdGVhY2hlciUyMGNsYXNzcm9vbXxlbnwxfHx8fDE3NzQ0MDk0ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    name: "Dr. Malika Azimova",
    subject: "Ingliz tili adabiyoti",
    department: "Gumanitar Fakulteti",
    office: "B Bino, 102-xona",
    email: "m.azimova@universitet.uz",
    phone: "+998 90 345 67 89",
    officeHours: "Dush, Pay 13:00-15:00",
    bio: "Ingliz tili va adabiyoti bo'yicha doktor. Zamonaviy va klassik adabiyot mutaxassisi. Talabalar orasida eng mashhur o'qituvchilardan biri.",
    image: "https://images.unsplash.com/photo-1758270704587-43339a801396?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmZW1hbGUlMjB0ZWFjaGVyJTIwcHJvZmVzc29yfGVufDF8fHx8MTc3NDQwOTQ4MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    name: "Prof. Bobur Karimov",
    subject: "Kompyuter fanlari",
    department: "Texnologiya Fakulteti",
    office: "Texnologiya Binosi, 401-xona",
    email: "b.karimov@universitet.uz",
    phone: "+998 90 456 78 90",
    officeHours: "Chor, Jum 10:00-12:00",
    bio: "Dasturlash va sun'iy intellekt bo'yicha professor. Zamonaviy texnologiyalar va AI sohasida etakchi mutaxassis.",
    image: "https://images.unsplash.com/flagged/photo-1559475555-b26777ed3ab4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwdGVhY2hlciUyMGNsYXNzcm9vbXxlbnwxfHx8fDE3NzQ0MDk0ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    name: "Dr. Dilnoza Yusupova",
    subject: "Kimyo",
    department: "Fan Fakulteti",
    office: "Laboratoriya Binosi, 310-xona",
    email: "d.yusupova@universitet.uz",
    phone: "+998 90 567 89 01",
    officeHours: "Sesh, Pay 14:00-16:00",
    bio: "Organik va noorganik kimyo bo'yicha doktor. Laboratoriya tajribalarida ko'p yillik tajribaga ega.",
    image: "https://images.unsplash.com/photo-1758270704925-fa59d93119c1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0ZWFjaGVyJTIwcHJvZmVzc29yJTIwY2xhc3Nyb29tfGVufDF8fHx8MTc3NDMwNTE1MXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    name: "Prof. Anvar Toshmatov",
    subject: "Tarix",
    department: "Gumanitar Fakulteti",
    office: "B Bino, 205-xona",
    email: "a.toshmatov@universitet.uz",
    phone: "+998 90 678 90 12",
    officeHours: "Dush, Chor 11:00-13:00",
    bio: "O'zbekiston va jahon tarixi bo'yicha professor. Qadimiy sivilizatsiyalar va zamonaviy tarix mutaxassisi.",
    image: "https://images.unsplash.com/flagged/photo-1559475555-b26777ed3ab4?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYWxlJTIwdGVhY2hlciUyMGNsYXNzcm9vbXxlbnwxfHx8fDE3NzQ0MDk0ODF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function TeachersPage() {
  const [selectedTeacher, setSelectedTeacher] = useState<TeacherType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (teacher: TeacherType) => {
    setSelectedTeacher(teacher);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-orange-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent mb-4">
              O'qituvchilar
            </h1>
            <p className="text-xl text-gray-300">
              O'qituvchilaringiz bilan tanishing
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {teachers.map((teacher, index) => (
            <motion.div
              key={teacher.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-orange-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-orange-500/20"
                onClick={() => handleCardClick(teacher)}
              >
                <div className="relative h-72 overflow-hidden">
                  <ImageWithFallback
                    src={teacher.image}
                    alt={teacher.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-orange-600/80 via-orange-600/40 to-transparent group-hover:from-orange-500/90 transition-all duration-500" />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-2 text-white group-hover:text-orange-400 transition-colors">
                    {teacher.name}
                  </h3>
                  <div className="flex items-center gap-2 mb-4">
                    <BookOpen className="size-4 text-orange-400" />
                    <p className="text-orange-400">{teacher.subject}</p>
                  </div>
                  <div className="space-y-2">
                    <p className="text-sm text-gray-400">{teacher.department}</p>
                    <div className="flex items-start gap-2">
                      <MapPin className="size-4 text-gray-500 mt-0.5 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{teacher.office}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedTeacher && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">
                  {selectedTeacher.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-80 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedTeacher.image}
                    alt={selectedTeacher.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-6 left-6">
                    <div className="flex items-center gap-3 bg-orange-600/90 backdrop-blur-sm px-4 py-2 rounded-full">
                      <BookOpen className="size-5 text-white" />
                      <p className="text-white">{selectedTeacher.subject}</p>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <p className="text-sm text-gray-400 mb-2">Kafedra</p>
                    <p className="text-gray-300">{selectedTeacher.department}</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <MapPin className="size-5 text-orange-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Xona</p>
                        <p className="text-gray-300">{selectedTeacher.office}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <Mail className="size-5 text-orange-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Email</p>
                        <p className="text-gray-300 break-all">{selectedTeacher.email}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <Phone className="size-5 text-orange-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Telefon</p>
                        <p className="text-gray-300">{selectedTeacher.phone}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                      <BookOpen className="size-5 text-orange-400 mt-1 flex-shrink-0" />
                      <div>
                        <p className="text-sm text-gray-400 mb-1">Qabul vaqti</p>
                        <p className="text-gray-300">{selectedTeacher.officeHours}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                    <p className="text-sm text-gray-400 mb-2">Biografiya</p>
                    <p className="text-gray-300 leading-relaxed">{selectedTeacher.bio}</p>
                  </div>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
