import { useState } from "react";
import { Link } from "react-router";
import { Card, CardContent } from "../components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../components/ui/dialog";
import { ArrowLeft, DollarSign, Clock, MapPin, Bus } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";
import { Button } from "../components/ui/button";
import { motion } from "motion/react";

interface TransportType {
  id: number;
  name: string;
  type: string;
  price: string;
  frequency: string;
  route: string;
  hours: string;
  details: string;
  coordinates: string;
  image: string;
}

const transportOptions: TransportType[] = [
  {
    id: 1,
    name: "24-avtobus yo'nalishi",
    type: "Jamoat avtobusi",
    price: "$1.50",
    frequency: "Har 15 daqiqada",
    route: "Markaziy Vokzal → Kampus → Shahar Markazi",
    hours: "5:30 - 23:00",
    details: "Eng mashxur avtobus yo'nalishi. Kampusga eng tez va qulay yo'l. Talabalar uchun chegirmalar mavjud.",
    coordinates: "41.3111,69.2797",
    image: "https://images.unsplash.com/photo-1543698376-9c76b08cd35d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjBidXMlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 2,
    name: "42-avtobus yo'nalishi",
    type: "Jamoat avtobusi",
    price: "$1.50",
    frequency: "Har 20 daqiqada",
    route: "Aeroport → Kampus → Savdo Markazi",
    hours: "6:00 - 22:00",
    details: "Aeroportdan kampusgacha to'g'ridan-to'g'ri yo'l. Katta yuklar uchun qulay.",
    coordinates: "41.3105,69.2790",
    image: "https://images.unsplash.com/photo-1543698376-9c76b08cd35d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjBidXMlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 3,
    name: "Metro 2-liniya",
    type: "Metro",
    price: "$2.00",
    frequency: "Har 10 daqiqada",
    route: "Shimoliy Terminal → Universitet Bekati → Janubiy Terminal",
    hours: "5:00 - 24:00",
    details: "Eng tez transport turi. Universitet bekati kampusdan 5 daqiqa piyoda masofada.",
    coordinates: "41.3100,69.2800",
    image: "https://images.unsplash.com/photo-1681950167930-793b3a179bf0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdWJ3YXklMjBtZXRybyUyMHRyYWlufGVufDF8fHx8MTc3NDMyNDIzNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 4,
    name: "Kampus Shuttli",
    type: "Universitet avtobusi",
    price: "Talabalar uchun bepul",
    frequency: "Har 30 daqiqada",
    route: "Yotoqxona hududi → Asosiy Kampus → Kutubxona → Sport Majmuasi",
    hours: "7:00 - 21:00",
    details: "Talabalar uchun bepul ichki kampus transporti. Talaba IDsi talab qilinadi.",
    coordinates: "41.3108,69.2795",
    image: "https://images.unsplash.com/photo-1543698376-9c76b08cd35d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjBidXMlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 5,
    name: "Taksi Xizmati",
    type: "Taksi",
    price: "$3.00 boshlang'ich + $0.80/km",
    frequency: "Buyurtma bo'yicha",
    route: "Shahar bo'ylab",
    hours: "24/7",
    details: "Qulaylik va tezkorlik. Mobil ilovalar orqali buyurtma qilish mumkin. Kechqurun xavfsiz sayohat.",
    coordinates: "41.3111,69.2797",
    image: "https://images.unsplash.com/photo-1652270625079-83dd767498db?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0YXhpJTIwY2FiJTIwc2VydmljZXxlbnwxfHx8fDE3NzQ0MDk0ODJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
  {
    id: 6,
    name: "Velosiped Ijarasi",
    type: "Velosiped",
    price: "$0.50/30 daqiqa",
    frequency: "Bekatlar orqali",
    route: "Kampus va shahar bo'ylab 20 bekat",
    hours: "24/7",
    details: "Ekologik toza va sog'lom transport. Mobil ilova orqali ochish. Birinchi 15 daqiqa bepul.",
    coordinates: "41.3110,69.2795",
    image: "https://images.unsplash.com/photo-1543698376-9c76b08cd35d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjBidXMlMjB0cmFuc3BvcnRhdGlvbnxlbnwxfHx8fDE3NzQ0MDk0Nzh8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
  },
];

export default function TransportPage() {
  const [selectedTransport, setSelectedTransport] = useState<TransportType | null>(null);
  const [isOpen, setIsOpen] = useState(false);

  const handleCardClick = (transport: TransportType) => {
    setSelectedTransport(transport);
    setIsOpen(true);
  };

  return (
    <div className="min-h-screen bg-black">
      <header className="relative overflow-hidden bg-gradient-to-br from-slate-900 via-indigo-900 to-slate-900">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDE2YzAtNi42MjcgNS4zNzMtMTIgMTItMTJzMTIgNS4zNzMgMTIgMTItNS4zNzMgMTItMTIgMTItMTItNS4zNzMtMTItMTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <Link to="/">
            <Button variant="ghost" className="mb-6 text-white hover:bg-white/10 backdrop-blur-sm border border-white/20">
              <ArrowLeft className="size-4 mr-2" />
              Bosh sahifaga qaytish
            </Button>
          </Link>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <h1 className="text-5xl bg-gradient-to-r from-indigo-400 to-blue-400 bg-clip-text text-transparent mb-4">
              Foydali Yo'nalishlar
            </h1>
            <p className="text-xl text-gray-300">
              Transport turlari va narxlar bo'yicha to'liq qo'llanma
            </p>
          </motion.div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {transportOptions.map((transport, index) => (
            <motion.div
              key={transport.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <Card 
                className="overflow-hidden bg-gradient-to-br from-white/5 to-white/10 backdrop-blur-xl border-white/20 hover:border-indigo-400/60 transition-all duration-500 cursor-pointer group hover:scale-105 hover:shadow-2xl hover:shadow-indigo-500/20"
                onClick={() => handleCardClick(transport)}
              >
                <div className="relative h-56 overflow-hidden">
                  <ImageWithFallback
                    src={transport.image}
                    alt={transport.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-indigo-600/80 via-indigo-600/40 to-transparent group-hover:from-indigo-500/90 transition-all duration-500" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-indigo-600 text-white px-3 py-1 rounded-full text-sm backdrop-blur-sm">
                      {transport.type}
                    </span>
                  </div>
                  <div className="absolute bottom-4 left-4">
                    <Bus className="size-10 text-white drop-shadow-lg" />
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl mb-3 text-white group-hover:text-indigo-400 transition-colors">
                    {transport.name}
                  </h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <DollarSign className="size-4 text-green-400 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{transport.price}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="size-4 text-indigo-400 flex-shrink-0" />
                      <p className="text-sm text-gray-300">{transport.frequency}</p>
                    </div>
                    <p className="text-sm text-gray-400 mt-3 line-clamp-2">{transport.route}</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-slate-900 to-slate-800 border-white/20 text-white">
          {selectedTransport && (
            <>
              <DialogHeader>
                <DialogTitle className="text-3xl bg-gradient-to-r from-indigo-400 to-blue-400 bg-clip-text text-transparent">
                  {selectedTransport.name}
                </DialogTitle>
              </DialogHeader>
              
              <div className="space-y-6">
                <div className="relative h-64 rounded-xl overflow-hidden">
                  <ImageWithFallback
                    src={selectedTransport.image}
                    alt={selectedTransport.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute top-4 right-4">
                    <span className="bg-indigo-600 text-white px-4 py-2 rounded-full backdrop-blur-sm">
                      {selectedTransport.type}
                    </span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                    <DollarSign className="size-5 text-green-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Narx</p>
                      <p className="text-gray-300">{selectedTransport.price}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10">
                    <Clock className="size-5 text-indigo-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Chastota</p>
                      <p className="text-gray-300">{selectedTransport.frequency}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10 md:col-span-2">
                    <MapPin className="size-5 text-red-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Yo'nalish</p>
                      <p className="text-gray-300">{selectedTransport.route}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3 bg-white/5 rounded-xl p-4 border border-white/10 md:col-span-2">
                    <Clock className="size-5 text-blue-400 mt-1 flex-shrink-0" />
                    <div>
                      <p className="text-sm text-gray-400 mb-1">Ish vaqti</p>
                      <p className="text-gray-300">{selectedTransport.hours}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                  <p className="text-gray-300 leading-relaxed">{selectedTransport.details}</p>
                </div>

                <div className="rounded-xl overflow-hidden border border-white/20">
                  <iframe
                    width="100%"
                    height="400"
                    frameBorder="0"
                    style={{ border: 0 }}
                    src={`https://www.google.com/maps?q=${selectedTransport.coordinates}&output=embed`}
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
