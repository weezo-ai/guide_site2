import { createBrowserRouter } from "react-router";
import Home from "./pages/Home";
import BuildingsPage from "./pages/BuildingsPage";
import OtherBuildingsPage from "./pages/OtherBuildingsPage";
import TeachersPage from "./pages/TeachersPage";
import SubjectsPage from "./pages/SubjectsPage";
import TransportPage from "./pages/TransportPage";
import AdvicesPage from "./pages/AdvicesPage";
import EventsPage from "./pages/EventsPage";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/buildings",
    Component: BuildingsPage,
  },
  {
    path: "/other-buildings",
    Component: OtherBuildingsPage,
  },
  {
    path: "/teachers",
    Component: TeachersPage,
  },
  {
    path: "/subjects",
    Component: SubjectsPage,
  },
  {
    path: "/transport",
    Component: TransportPage,
  },
  {
    path: "/advices",
    Component: AdvicesPage,
  },
  {
    path: "/events",
    Component: EventsPage,
  },
]);